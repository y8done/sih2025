from fastapi import FastAPI
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from fastapi.responses import JSONResponse
import numpy as np
import pandas as pd

app = FastAPI(title="Simulation API")

# Define input model
class ProjectData(BaseModel):
    Weight_kg: List[Optional[float]]
    Recycled_Content_percent: List[Optional[float]]
    Energy_Extraction_MJ: List[Optional[float]]
    Energy_Manufacturing_MJ: List[Optional[float]]
    Transport_km: List[Optional[float]]
    Transport_Mode: List[str]
    CO2_Extraction_kg: List[Optional[float]]
    CO2_Manufacturing_kg: List[Optional[float]]
    Material_Cost_USD: List[Optional[float]]

@app.post("/simulate")
def simulate_project(data: ProjectData, scenario: Optional[str] = "both") -> Dict[str, Any]:
    # Convert input to DataFrame
    df = pd.DataFrame(data.dict())
    
    # Track missing values
    missing_mask = df.isnull()
    
    # Simple imputation: fill missing numeric values with column mean
    for col in df.select_dtypes(include=[np.number]).columns:
        df[col] = df[col].fillna(df[col].mean())
    
    # Example calculation for linear & circular scenario
    linear_CO2 = df['CO2_Extraction_kg'].sum() + df['CO2_Manufacturing_kg'].sum()
    circular_CO2 = linear_CO2 * 0.8  # assume 20% reduction
    
    linear_energy = df['Energy_Extraction_MJ'].sum() + df['Energy_Manufacturing_MJ'].sum()
    circular_energy = linear_energy * 0.8
    
    linear_cost = df['Material_Cost_USD'].sum()
    circular_cost = linear_cost * 0.95  # assume cost savings
    
    # Circularity metrics
    circularity = {
        "linear": {"MCI": 0, "Recycling_rate": 0, "Loops": 0},
        "circular": {"MCI": 0.4, "Recycling_rate": 0.4, "Loops": 2}
    }
    
    recommendation = "Recommended scenario: circular" if circular_CO2 < linear_CO2 else "Recommended scenario: linear"
    
    # Create ai_mask for which values were imputed
    ai_mask = missing_mask.astype(bool).to_dict()
    
    response = {
        "results": {
            "linear": {
                "CO2_total_kg": linear_CO2,
                "Energy_total_MJ": linear_energy,
                "Cost_total_USD": linear_cost,
                "Circularity": circularity["linear"]
            },
            "circular": {
                "CO2_total_kg": circular_CO2,
                "Energy_total_MJ": circular_energy,
                "Cost_total_USD": circular_cost,
                "Circularity": circularity["circular"]
            },
            "recommendation": recommendation
        },
        "metadata": {
            "scenario": scenario,
            "data_points": len(df),
            "imputation": {
                "total_missing_values": int(missing_mask.sum().sum()),
                "values_imputed": int(missing_mask.sum().sum()),
                "columns_with_missing": int(missing_mask.any().sum()),
                "ai_mask": ai_mask
            }
        }
    }
    
    return JSONResponse(content=response)






